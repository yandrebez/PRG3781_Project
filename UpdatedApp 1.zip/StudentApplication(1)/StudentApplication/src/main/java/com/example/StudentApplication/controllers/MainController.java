package com.example.StudentApplication.controllers;

public class MainController {
}
