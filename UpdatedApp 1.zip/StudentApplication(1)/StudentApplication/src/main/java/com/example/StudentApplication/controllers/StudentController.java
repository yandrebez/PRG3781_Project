package com.example.StudentApplication.controllers;

import com.example.StudentApplication.service.MyStudentDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.ui.Model;
import com.example.StudentApplication.model.Student;
import org.springframework.stereotype.Controller;


@Controller
public class StudentController {

    @Autowired
    private MyStudentDetailsService myStudentDetailsService;

    public StudentController(MyStudentDetailsService myStudentDetailsService){
        this.myStudentDetailsService = myStudentDetailsService;
    }

    //display html register page
    @GetMapping("/registration")
    public String showRegistrationForm(Model model){
        model.addAttribute("student", new Student());
        return "registration";
    }

    
    @PostMapping("/registration")
    public String registerStudent(@ModelAttribute("student") Student student){
        studentRepo.save(student);
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginForm(){
        return "login";
    }
}
