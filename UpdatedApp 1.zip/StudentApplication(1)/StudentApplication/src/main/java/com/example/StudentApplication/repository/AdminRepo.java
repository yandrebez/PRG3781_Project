package com.example.StudentApplication.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.StudentApplication.model.Admin;


public interface AdminRepo extends JpaRepository<Admin, Integer>{

    Optional<Admin> findByNameAndPassword(String name,String password);

    Optional<Admin> findFirstByName(String name);

}