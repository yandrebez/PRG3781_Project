package com.example.StudentApplication.repository;

import com.example.StudentApplication.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StudentRepo extends JpaRepository<Student, Long> {
    //methods we want to use
    Optional<Student> findByUsernameAndPassword(String username,String password);

    Optional<Student> findFirstByUsername(String username);
}
