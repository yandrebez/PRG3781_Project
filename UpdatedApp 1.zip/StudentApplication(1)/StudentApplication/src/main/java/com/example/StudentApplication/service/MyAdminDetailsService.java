package com.example.StudentApplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.StudentApplication.model.Admin;
import com.example.StudentApplication.repository.AdminRepo;


@Service
public class MyAdminDetailsService {

    @Autowired
    private AdminRepo adminRepository;

    public MyAdminDetailsService(AdminRepo adminRepository) {
        this.adminRepository = adminRepository;
    }

    public Admin registerAdmin(String name, String contact, String password) {
        if (name == null || password == null) {
            return null;
        } else {
            if (adminRepository.findFirstByName(name).isPresent()) {
                System.out.println("Duplicate login");
                return null;
            }
            Admin adminModel = new Admin();
            adminModel.setName(name);
            adminModel.setContact(contact);
            ;
            adminModel.setPassword(password);
            return adminRepository.save(adminModel);
        }
    }

    public Admin authenticate(String name, String password) {
        return adminRepository.findByNameAndPassword(name, password).orElse(null);
    }
}
