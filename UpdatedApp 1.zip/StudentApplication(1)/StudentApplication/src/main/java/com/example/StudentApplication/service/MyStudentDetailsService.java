package com.example.StudentApplication.service;

import com.example.StudentApplication.repository.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.StudentApplication.model.Student;

public class MyStudentDetailsService{

    @Autowired
    private StudentRepo studentRepo;

    //constractor
    public MyStudentDetailsService(StudentRepo studentRepo) {
        this.studentRepo = studentRepo;
    }

    //saving student to database
    public Student registerStudent(String username, String email, String address,String course,String password){
        if (username == null || password == null) {
            return null;
        } else {
            if(studentRepo.findFirstByUsername(username).isPresent()){
                System.out.println("Duplicate Name found");
                return null;
            }
            Student studentModel=new Student();
            studentModel.setUsername(username);
            studentModel.setEmail(email);
            studentModel.setAddress(address);
            studentModel.setCourse(course);
            studentModel.setPassword(password);

            return studentRepo.save(studentModel);
        }
    }
    //helps login by using name and password
    public  Student authenticate(String username,String password){
        return  studentRepo.findByUsernameAndPassword(username,password).orElse(null);
    }
}
