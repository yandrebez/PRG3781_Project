package com.example.StudentApplication.service;

import java.util.List;

import com.example.StudentApplication.model.Student;

public interface StudService {

    List<Student>getAllStudent();

    void saveStudent(Student studentModel);

    Student getStudentById(Integer id);

    void deleteStudentById(Integer id);
}
