package com.example.StudentApplication.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.StudentApplication.model.Student;
import com.example.StudentApplication.repository.StudRepo;

@Service
public class StudServiceImp implements StudService{

    @Autowired
    private StudRepo studRepo;

    //get all user in a list
    @Override
    public List<Student> getAllStudent() {
        return studRepo.findAll();
    }

    @Override
    public void saveStudent(Student student) {
        this.studRepo.save(student);

    }

    @Override
    public Student getStudentById(Integer id) {
        Optional<Student> optional = studRepo.findById(id);
        Student student;
        if(optional.isPresent()) {
            student = optional.get();
        }else{

            throw new RuntimeException("User not found"+id);
        }
        return student;
    }

    @Override
    public void deleteStudentById(Integer id) {
        this.studRepo.deleteById(id);
    }
}